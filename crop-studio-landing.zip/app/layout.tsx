import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import type React from "react"
import { ScrollToTop } from "@/components/ScrollToTop"
import { Analytics } from "@vercel/analytics/react"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Crop Studio - Protect Your Privacy, Share What Matters",
  description: "Advanced screen sharing and workflow optimization tool",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.className} bg-black text-white antialiased`}>
        <main className="content-spacing">{children}</main>
        <ScrollToTop />
        <Analytics />
      </body>
    </html>
  )
}



import './globals.css'