"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { BookWaitlistModal } from "@/components/BookWaitlistModal"
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel"

const ResourceCard = ({ resource }) => {
  const Icon = resource.icon

  return (
    <a
      href={resource.action?.href || "#"}
      target="_blank"
      rel="noopener noreferrer"
      className="block"
      onClick={(e) => {
        if (resource.action?.onClick) {
          e.preventDefault()
          resource.action.onClick()
        }
      }}
    >
      <div
        className="relative overflow-hidden rounded-lg cursor-pointer transition-all duration-300 h-[220px] flex flex-col justify-center items-center p-4"
        style={{
          backgroundColor: resource.color,
        }}
      >
        <Icon className="w-12 h-12 text-white mb-4" />
        <h2 className="text-xl font-bold text-white text-center mb-2">{resource.title}</h2>
        <p className="text-sm text-gray-200 text-center">{resource.description}</p>
      </div>
    </a>
  )
}

export default function ResourcesPage() {
  const [bookWaitlistModalOpen, setBookWaitlistModalOpen] = useState(false)
  const [selectedWorkshop, setSelectedWorkshop] = useState("")
  const [resources, setResources] = useState([])

  useEffect(() => {
    async function fetchResources() {
      const res = await fetch("/api/resources")
      const data = await res.json()
      setResources(data)
    }
    fetchResources()
  }, [])

  const handleWorkshopClick = (workshopTitle: string) => {
    setSelectedWorkshop(workshopTitle)
    setBookWaitlistModalOpen(true)
  }

  return (
    <main className="min-h-screen bg-black text-white">
      <Header />

      <section className="pt-32 pb-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-center text-white">
            Laboratório de Recursos para PMs 🧪🔬
          </h1>
          <p className="text-xl text-gray-400 text-center mb-12 max-w-2xl mx-auto">
            Explore nossa biblioteca de recursos. Clique em uma pasta para abrir o recurso em uma nova guia.
          </p>

          <Carousel className="w-full max-w-6xl mx-auto mb-12">
            <CarouselContent className="-ml-2 md:-ml-4">
              {resources.map((resource) => (
                <CarouselItem key={resource.id} className="pl-2 md:pl-4 basis-1/2 md:basis-1/3 lg:basis-1/4">
                  <ResourceCard resource={resource} />
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious />
            <CarouselNext />
          </Carousel>
        </div>
      </section>

      <BookWaitlistModal isOpen={bookWaitlistModalOpen} onClose={() => setBookWaitlistModalOpen(false)} />
    </main>
  )
}

