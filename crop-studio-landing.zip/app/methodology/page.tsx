"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { ShineBorder } from "@/components/ui/shine-border"
import { Button } from "@/components/ui/button"
import { ArrowRight, Brain, Rocket, Target, Users, BarChart, Zap } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

const methodologySteps = [
  {
    title: "Avaliação Inicial",
    description: "Utilizamos IA para analisar suas habilidades atuais e identificar áreas de melhoria.",
    icon: Brain,
  },
  {
    title: "Plano Personalizado",
    description: "Criamos um roteiro de aprendizado adaptado às suas necessidades e objetivos de carreira.",
    icon: Target,
  },
  {
    title: "Aprendizado Prático",
    description: "Aplicação de conhecimentos em projetos reais e simulações de cenários de produto.",
    icon: Rocket,
  },
  {
    title: "Mentoria Especializada",
    description: "Sessões individuais com PMs experientes para orientação e feedback.",
    icon: Users,
  },
  {
    title: "Análise de Progresso",
    description: "Monitoramento contínuo do seu desenvolvimento com métricas e KPIs personalizados.",
    icon: BarChart,
  },
  {
    title: "Aprimoramento Contínuo",
    description: "Atualização constante do plano de aprendizado com base no seu progresso e nas tendências do mercado.",
    icon: Zap,
  },
]

export default function MethodologyPage() {
  const [activeStep, setActiveStep] = useState(0)

  return (
    <main className="min-h-screen bg-black">
      <Header />
      <section className="pt-32 pb-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-8 text-center text-white">
            Nossa Metodologia: Formando PMs do Futuro
          </h1>
          <p className="text-xl text-gray-400 text-center mb-16 max-w-3xl mx-auto">
            Nossa abordagem única combina tecnologia de ponta, experiência prática e mentoria personalizada para
            transformar profissionais em Product Managers excepcionais.
          </p>

          <div className="grid md:grid-cols-2 gap-16 items-center mb-16">
            <div>
              <ShineBorder className="p-8 bg-gray-900/50 rounded-xl overflow-hidden">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Frame%202214%20(1)-1mcwneSEbDfSn1Z9Bkta7nNoSogfX5.svg"
                  alt="AI-Powered Skill Assessment"
                  width={800}
                  height={600}
                  className="w-full h-auto rounded-lg"
                />
              </ShineBorder>
            </div>
            <div>
              <h2 className="text-3xl font-bold mb-6 text-white">Metodologia Baseada em IA</h2>
              <p className="text-gray-400 mb-8">
                Nossa metodologia utiliza inteligência artificial para avaliar suas habilidades, criar um plano de
                aprendizado personalizado e acompanhar seu progresso em tempo real. Combinamos o poder da IA com a
                experiência de mentores especialistas para oferecer uma jornada de aprendizado única e eficaz.
              </p>
              <div className="space-y-4">
                {methodologySteps.map((step, index) => (
                  <ShineBorder
                    key={index}
                    className={`p-4 rounded-lg cursor-pointer transition-all duration-300 ${
                      activeStep === index ? "bg-yellow-400/20" : "bg-gray-900/50 hover:bg-gray-800/50"
                    }`}
                    onClick={() => setActiveStep(index)}
                  >
                    <div className="flex items-center gap-4">
                      <div className="bg-yellow-400 p-2 rounded-full">
                        <step.icon className="w-6 h-6 text-black" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-white">{step.title}</h3>
                        <p className="text-sm text-gray-400">{step.description}</p>
                      </div>
                    </div>
                  </ShineBorder>
                ))}
              </div>
            </div>
          </div>

          <div className="text-center">
            <Link href="/programs" passHref>
              <Button className="bg-yellow-400 text-black hover:bg-yellow-500">
                Explore Nossos Programas
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </main>
  )
}

