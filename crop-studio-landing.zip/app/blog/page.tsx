import { Header } from "@/components/header"
import BlogContent from "./BlogContent"
import { getBlogPosts } from "./blogData"

export default async function BlogPage() {
  const blogPosts = await getBlogPosts()

  return (
    <main className="min-h-screen bg-black">
      <Header />
      <BlogContent initialPosts={blogPosts} />
    </main>
  )
}

