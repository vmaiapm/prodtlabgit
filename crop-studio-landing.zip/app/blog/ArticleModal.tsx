import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { X } from "lucide-react"
import Image from "next/image"
import type { BlogPost } from "./blogData"

interface ArticleModalProps {
  isOpen: boolean
  onClose: () => void
  post: BlogPost
}

export function ArticleModal({ isOpen, onClose, post }: ArticleModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="w-full h-screen p-0 overflow-hidden flex flex-col bg-black text-white">
        <DialogHeader className="p-6 sticky top-0 z-10 bg-black">
          <div className="flex justify-between items-center">
            <DialogTitle className="text-3xl font-bold text-yellow-400">{post.title}</DialogTitle>
            <Button variant="ghost" size="icon" onClick={onClose} className="text-white">
              <X className="h-6 w-6" />
            </Button>
          </div>
        </DialogHeader>
        <div className="flex-grow overflow-y-auto p-6 bg-black">
          <div className="prose prose-invert max-w-none">
            <h1 className="text-4xl font-bold mb-6">{post.title}</h1>
            <div className="flex items-center mb-6">
              <Image
                src={post.authorImage || "/placeholder.svg"}
                alt={post.author}
                width={64}
                height={64}
                className="rounded-full mr-4"
              />
              <div>
                <p className="text-white font-semibold">{post.author}</p>
                <p className="text-gray-400">
                  {new Date(post.date).toLocaleDateString()} • {post.readTime}
                </p>
              </div>
            </div>
            <div dangerouslySetInnerHTML={{ __html: post.content }} />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
;<style jsx global>{`
  .prose h2 {
    font-size: 1.5em;
    font-weight: 600;
    margin-top: 1.5em;
    margin-bottom: 0.5em;
  }
  .prose h3 {
    font-size: 1.25em;
    font-weight: 600;
    margin-top: 1.5em;
    margin-bottom: 0.5em;
  }
  .prose p {
    margin-bottom: 1em;
    line-height: 1.6;
  }
  .prose ul, .prose ol {
    margin-bottom: 1em;
    padding-left: 1.5em;
  }
  .prose li {
    margin-bottom: 0.5em;
  }
`}</style>

