import { getBlogPosts } from "../blogData"
import { notFound } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import dynamic from "next/dynamic"
import { parse } from "node-html-parser"
import { ArrowLeft } from "lucide-react"

const DynamicArticleContent = dynamic(() => import("./ArticleContent"), { ssr: false })

export async function generateStaticParams() {
  const posts = await getBlogPosts()
  return posts.map((post) => ({
    slug: post.slug,
  }))
}

function generateTableOfContents(content: string) {
  try {
    const root = parse(content)
    const headings = root.querySelectorAll("h2, h3")
    return headings.map((heading) => ({
      id: heading.id || heading.textContent.toLowerCase().replace(/\s+/g, "-"),
      text: heading.textContent,
      level: heading.tagName === "H2" ? 2 : 3,
    }))
  } catch (error) {
    console.error("Error generating table of contents:", error)
    return []
  }
}

function enhanceContent(content: string) {
  try {
    const root = parse(content)
    root.querySelectorAll("h2, h3").forEach((heading) => {
      if (!heading.id) {
        heading.setAttribute("id", heading.textContent.toLowerCase().replace(/\s+/g, "-"))
      }
    })
    return root.toString()
  } catch (error) {
    console.error("Error enhancing content:", error)
    return content
  }
}

export default async function BlogPost({ params }: { params: { slug: string } }) {
  const posts = await getBlogPosts()
  const post = posts.find((p) => p.slug === params.slug)

  if (!post) {
    notFound()
  }

  const enhancedContent = enhanceContent(post.content)
  const tableOfContents = generateTableOfContents(post.content)

  return (
    <article className="min-h-screen bg-black text-white">
      <div className="container mx-auto px-4 py-16 max-w-4xl">
        <header className="mb-12">
          <Link
            href="/blog"
            className="inline-flex items-center bg-gray-800 text-gray-300 hover:bg-gray-700 hover:text-white px-4 py-2 rounded-full transition-colors duration-200 mb-6"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Voltar para o Blog
          </Link>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 text-yellow-400 leading-tight">
            {post.title}
          </h1>
          <div className="flex items-center">
            <Image
              src={post.authorImage || "/placeholder.svg"}
              alt={post.author}
              width={64}
              height={64}
              className="rounded-full mr-4"
            />
            <div>
              <p className="text-white font-semibold">{post.author}</p>
              <p className="text-gray-400">
                {new Date(post.date).toLocaleDateString()} • {post.readTime}
              </p>
            </div>
          </div>
        </header>

        <DynamicArticleContent tableOfContents={tableOfContents} post={post} />

        <div className="bg-gray-900 p-8 rounded-lg mb-12">
          <h2 className="text-2xl font-bold mb-4">Recursos Gratuitos</h2>
          <p className="mb-4">Aprimore suas habilidades em Product Management com nossos recursos gratuitos.</p>
          <Link href="/recursos-gratuitos" passHref>
            <Button className="bg-yellow-400 text-black hover:bg-yellow-500">Explorar Recursos Gratuitos</Button>
          </Link>
        </div>

        <div className="bg-gray-900 p-8 rounded-lg">
          <h2 className="text-2xl font-bold mb-4">Programas Pagos</h2>
          <p className="mb-4">Leve sua carreira ao próximo nível com nossos programas especializados.</p>
          <Link href="/programas" passHref>
            <Button className="bg-yellow-400 text-black hover:bg-yellow-500">Ver Programas</Button>
          </Link>
        </div>
      </div>
    </article>
  )
}

