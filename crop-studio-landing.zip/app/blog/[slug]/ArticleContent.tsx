"use client"

import Image from "next/image"
import type { BlogPost } from "../blogData"

export default function ArticleContent({ post }: { post: BlogPost }) {
  return (
    <div className="w-full">
      <div className="prose prose-invert max-w-none mb-12">
        {post.sections.map((section, index) => (
          <div key={index}>
            <div dangerouslySetInnerHTML={{ __html: section.content }} />
            {section.image && (
              <div className="my-8">
                <Image
                  src={section.image.src || "/placeholder.svg"}
                  alt={section.image.alt}
                  width={800}
                  height={600}
                  className="rounded-lg w-full"
                />
                <p className="text-sm text-gray-400 mt-2">{section.image.alt}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

