"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { AnimatedElement } from "@/components/AnimatedElement"
import { BlurredSection } from "@/components/BlurredSection"
import Image from "next/image"
import { BookOpen, Share2 } from "lucide-react"
import type { BlogPost } from "./blogData"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import Link from "next/link"

interface BlogContentProps {
  initialPosts: BlogPost[]
}

export default function BlogContent({ initialPosts }: BlogContentProps) {
  const [posts] = useState(initialPosts)

  const sharePost = (platform: string, post: BlogPost) => {
    const url = `${window.location.origin}/blog/${post.slug}`
    const text = `Check out this article: ${post.title}`

    switch (platform) {
      case "twitter":
        window.open(
          `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`,
          "_blank",
        )
        break
      case "facebook":
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, "_blank")
        break
      case "linkedin":
        window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`, "_blank")
        break
    }
  }

  return (
    <BlurredSection>
      <section className="pt-32 pb-16">
        <div className="container mx-auto px-4">
          <AnimatedElement>
            <h1 className="text-4xl md:text-5xl font-bold mb-8 text-center text-white">Blog prodt lab</h1>
            <p className="text-xl text-gray-400 text-center mb-12 max-w-2xl mx-auto">
              Insights, dicas e tendências sobre Product Management e IA para impulsionar sua carreira e seus produtos.
            </p>
          </AnimatedElement>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {posts.map((post) => (
              <AnimatedElement key={post.slug}>
                <div className="group bg-gray-900/50 rounded-lg overflow-hidden shadow-lg hover:bg-gray-900/70 transition-all duration-300 flex flex-col h-full">
                  <div className="relative h-48">
                    <Image
                      src={post.image || "/placeholder.svg"}
                      alt={post.title}
                      layout="fill"
                      objectFit="cover"
                      className="transition-transform duration-300 group-hover:scale-105"
                    />
                    <div className="absolute bottom-0 left-0 w-full p-4 bg-gradient-to-t from-black/80 to-transparent">
                      <div className="flex items-center">
                        <Image
                          src={post.authorImage || "/placeholder.svg"}
                          alt={post.author}
                          width={32}
                          height={32}
                          className="rounded-full border-2 border-white/20"
                        />
                        <div className="ml-2">
                          <p className="text-white text-sm font-medium">{post.author}</p>
                          <p className="text-xs text-gray-300">{post.readTime}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="p-4 flex-grow flex flex-col justify-between">
                    <div>
                      <h2 className="text-xl font-bold mb-2 text-white group-hover:text-yellow-400 transition-colors">
                        {post.title}
                      </h2>
                      <p className="text-gray-400 text-sm mb-4 line-clamp-3">{post.excerpt}</p>
                    </div>
                    <div className="flex items-center justify-between mt-auto">
                      <span className="text-xs text-gray-500">{new Date(post.date).toLocaleDateString()}</span>
                      <div className="flex gap-2">
                        <Link href={`/blog/${post.slug}`} passHref>
                          <Button size="sm" variant="ghost" className="hover:bg-yellow-400/20 hover:text-yellow-400">
                            <BookOpen className="w-4 h-4 mr-1" />
                            Ler
                          </Button>
                        </Link>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button size="sm" variant="ghost" className="hover:bg-yellow-400/20 hover:text-yellow-400">
                              <Share2 className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent>
                            <DropdownMenuItem onClick={() => sharePost("twitter", post)}>Twitter</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => sharePost("facebook", post)}>Facebook</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => sharePost("linkedin", post)}>LinkedIn</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  </div>
                </div>
              </AnimatedElement>
            ))}
          </div>
        </div>
      </section>
    </BlurredSection>
  )
}

