import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { ShineBorder } from "@/components/ui/shine-border"
import {
  Building2,
  Users,
  Zap,
  ArrowRight,
  Briefcase,
  ClapperboardIcon as ChalkboardTeacher,
  LineChart,
  PhoneIcon as WhatsappIcon,
} from "lucide-react"

export default function ParaEmpresasPage() {
  return (
    <main className="min-h-screen bg-black">
      <Header />
      <section className="pt-32 pb-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-8 text-center text-white">
            Soluções Empresariais para Equipes de Produto
          </h1>
          <p className="text-xl text-gray-400 text-center mb-16 max-w-3xl mx-auto">
            Potencialize sua equipe de produto com treinamentos personalizados, workshops, e consultoria especializada.
            Transforme sua organização com as melhores práticas de Product Management.
          </p>

          <div className="grid md:grid-cols-2 gap-16 items-start mb-16">
            <div>
              <h2 className="text-3xl font-bold mb-6 text-white">Por que escolher o prodt lab para sua empresa?</h2>
              <div className="space-y-6">
                {[
                  {
                    icon: Building2,
                    title: "Soluções Personalizadas",
                    description: "Programas adaptados às necessidades específicas da sua empresa e equipe.",
                  },
                  {
                    icon: Users,
                    title: "Mentoria de Especialistas",
                    description: "Acesso a mentores com vasta experiência em gestão de produtos em grandes empresas.",
                  },
                  {
                    icon: Zap,
                    title: "Metodologia Baseada em IA",
                    description: "Utilizamos IA para otimizar o aprendizado e desenvolvimento da sua equipe.",
                  },
                  {
                    icon: Briefcase,
                    title: "Consultoria Especializada",
                    description: "Apoio estratégico para implementação e melhoria de processos de produto.",
                  },
                ].map((feature, index) => (
                  <ShineBorder key={index} className="p-4 bg-gray-900/50 rounded-lg border-gray-700">
                    <div className="flex items-start gap-4">
                      <div className="bg-gray-700 p-2 rounded-full">
                        <feature.icon className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-white">{feature.title}</h3>
                        <p className="text-sm text-gray-400">{feature.description}</p>
                      </div>
                    </div>
                  </ShineBorder>
                ))}
              </div>
            </div>

            <ShineBorder className="p-6 bg-gray-900/50 rounded-lg">
              <h3 className="text-2xl font-bold mb-6 text-white">Entre em contato</h3>
              <p className="text-gray-400 mb-6">
                Estamos prontos para discutir como podemos ajudar sua empresa a alcançar novos patamares em gestão de
                produtos. Clique no botão abaixo para iniciar uma conversa no WhatsApp.
              </p>
              <a
                href="https://wa.me/5511999999999?text=Olá,%20gostaria%20de%20saber%20mais%20sobre%20os%20serviços%20para%20empresas%20do%20prodt%20lab."
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button className="w-full bg-gray-700 text-white hover:bg-gray-600">
                  <WhatsappIcon className="w-5 h-5 mr-2" />
                  Fale Conosco no WhatsApp
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </a>
            </ShineBorder>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-900">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-center text-white">Nossos Serviços para Empresas</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: ChalkboardTeacher,
                title: "Treinamentos In-Company",
                description:
                  "Programas de capacitação personalizados para sua equipe, realizados em sua empresa ou remotamente.",
              },
              {
                icon: Briefcase,
                title: "Consultoria Especializada",
                description:
                  "Apoio estratégico para implementação e melhoria de processos de produto, alinhados às melhores práticas do mercado.",
              },
              {
                icon: LineChart,
                title: "Avaliação e Diagnóstico",
                description:
                  "Análise detalhada da maturidade de produto da sua organização, com recomendações práticas para evolução.",
              },
            ].map((service, index) => (
              <ShineBorder key={index} className="p-6 bg-black rounded-lg">
                <div className="flex flex-col items-center text-center">
                  <div className="bg-gray-700 p-3 rounded-full mb-4">
                    <service.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2 text-white">{service.title}</h3>
                  <p className="text-gray-400">{service.description}</p>
                </div>
              </ShineBorder>
            ))}
          </div>
        </div>
      </section>
    </main>
  )
}

