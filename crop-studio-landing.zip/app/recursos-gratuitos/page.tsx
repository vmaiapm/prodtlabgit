"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { ShineBorder } from "@/components/ui/shine-border"
import { BookOpen, FileText, Headphones, FileSpreadsheet, ArrowRight } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { AnimatedElement } from "@/components/AnimatedElement"
import { BlurredSection } from "@/components/BlurredSection"
import { BookWaitlistModal } from "@/components/BookWaitlistModal"

const resources = [
  {
    title: "Papo de Produto",
    description: "Podcast com conversas autênticas sobre gestão de produtos",
    icon: Headphones,
    color: "#34495E",
    action: {
      text: "Ouça no Spotify",
      href: "https://open.spotify.com/show/6deUaOxztKmZZFE97FzhFg",
    },
  },
  {
    title: "Blog prodt lab",
    description: "Artigos e insights sobre Product Management",
    icon: FileText,
    color: "#2C3E50",
    action: {
      text: "Ler Artigos",
      href: "/blog",
    },
  },
  {
    title: "Product Manager do Futuro",
    description: "Livro essencial para PMs na era da IA",
    icon: BookOpen,
    color: "#4A4A4A",
    action: {
      text: "Lista de Espera",
      onClick: () => {},
    },
  },
  {
    title: "Templates para PMs",
    description: "Ferramentas práticas para seu dia a dia",
    icon: FileSpreadsheet,
    color: "#5D6D7E",
    action: {
      text: "Baixar Templates",
      href: "#templates",
    },
  },
]

const blogPosts = [
  {
    title: "Como a IA está transformando o Product Management",
    description: "Descubra as principais tendências e aplicações da IA no mundo dos produtos digitais.",
    image: "/placeholder.svg?height=200&width=300",
    link: "/blog/ia-transformando-product-management",
  },
  {
    title: "5 métricas essenciais para Product Managers",
    description: "Aprenda a medir o sucesso do seu produto com estas métricas fundamentais.",
    image: "/placeholder.svg?height=200&width=300",
    link: "/blog/metricas-essenciais-product-managers",
  },
  {
    title: "O papel do PM na era do desenvolvimento ágil",
    description: "Como navegar e liderar em ambientes de desenvolvimento ágil.",
    image: "/placeholder.svg?height=200&width=300",
    link: "/blog/pm-era-desenvolvimento-agil",
  },
]

export default function RecursosGratuitosPage() {
  const [bookWaitlistModalOpen, setBookWaitlistModalOpen] = useState(false)

  return (
    <main className="min-h-screen bg-black text-white">
      <Header />
      <section className="pt-32 pb-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-center text-white">
            Recursos Gratuitos para Product Managers
          </h1>
          <p className="text-xl text-gray-400 text-center mb-12 max-w-2xl mx-auto">
            Explore nossa coleção de recursos gratuitos para impulsionar sua carreira em Product Management.
          </p>

          <BlurredSection>
            <AnimatedElement>
              <div className="grid md:grid-cols-2 gap-8 mb-16">
                {resources.map((resource, index) => (
                  <ShineBorder key={index} className="p-6 bg-gray-900/50 rounded-lg">
                    <div className="flex items-start gap-4">
                      <div className="bg-gray-800 p-3 rounded-full">
                        <resource.icon className="w-6 h-6 text-brand-500" />
                      </div>
                      <div className="flex-grow">
                        <h2 className="text-xl font-semibold mb-2 text-white">{resource.title}</h2>
                        <p className="text-gray-400 mb-4">{resource.description}</p>
                        {resource.action.onClick ? (
                          <Button
                            className="bg-brand-500 text-black hover:bg-brand-600"
                            onClick={() => {
                              if (resource.title === "Product Manager do Futuro") {
                                setBookWaitlistModalOpen(true)
                              } else {
                                resource.action.onClick()
                              }
                            }}
                          >
                            {resource.action.text}
                          </Button>
                        ) : (
                          <Link href={resource.action.href}>
                            <Button className="bg-brand-500 text-black hover:bg-brand-600">
                              {resource.action.text}
                            </Button>
                          </Link>
                        )}
                      </div>
                    </div>
                  </ShineBorder>
                ))}
              </div>
            </AnimatedElement>
          </BlurredSection>

          <BlurredSection>
            <AnimatedElement>
              <div className="mb-16">
                <h2 className="text-3xl font-bold mb-8 text-center text-white">Artigos em Destaque</h2>
                <div className="grid md:grid-cols-3 gap-8">
                  {blogPosts.map((post, index) => (
                    <ShineBorder key={index} className="p-4 bg-gray-900/50 rounded-lg">
                      <Image
                        src={post.image || "/placeholder.svg"}
                        alt={post.title}
                        width={300}
                        height={200}
                        className="rounded-lg mb-4"
                      />
                      <h3 className="text-lg font-semibold mb-2 text-white">{post.title}</h3>
                      <p className="text-sm text-gray-400 mb-4">{post.description}</p>
                      <Link href={post.link}>
                        <Button className="w-full bg-brand-500 text-black hover:bg-brand-600">
                          Ler Artigo <ArrowRight className="w-4 h-4 ml-2" />
                        </Button>
                      </Link>
                    </ShineBorder>
                  ))}
                </div>
              </div>
            </AnimatedElement>
          </BlurredSection>

          <BlurredSection>
            <AnimatedElement>
              <div id="templates" className="mt-16">
                <h2 className="text-3xl font-bold mb-8 text-center text-white">Templates para Product Managers</h2>
                <div className="grid md:grid-cols-3 gap-8">
                  {[
                    { name: "Product Roadmap", image: "/placeholder.svg?height=200&width=300" },
                    { name: "User Persona", image: "/placeholder.svg?height=200&width=300" },
                    { name: "Feature Prioritization", image: "/placeholder.svg?height=200&width=300" },
                  ].map((template, index) => (
                    <ShineBorder key={index} className="p-4 bg-gray-900/50 rounded-lg">
                      <Image
                        src={template.image || "/placeholder.svg"}
                        alt={template.name}
                        width={300}
                        height={200}
                        className="rounded-lg mb-4"
                      />
                      <h3 className="text-lg font-semibold mb-2 text-white">{template.name}</h3>
                      <Button className="w-full bg-brand-500 text-black hover:bg-brand-600">
                        Baixar Template <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </ShineBorder>
                  ))}
                </div>
              </div>
            </AnimatedElement>
          </BlurredSection>
        </div>
      </section>

      <BookWaitlistModal isOpen={bookWaitlistModalOpen} onClose={() => setBookWaitlistModalOpen(false)} />
    </main>
  )
}

