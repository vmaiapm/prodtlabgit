import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { ProgramsSection } from "@/components/programs-section"
import { CurriculumSection } from "@/components/curriculum-section"
import { MarketReferencesSection } from "@/components/market-references-section"
import { MentorsSection } from "@/components/mentors-section"
import { AnimatedElement } from "@/components/AnimatedElement"
import { BlurredSection } from "@/components/BlurredSection"

export default function Home() {
  return (
    <div className="min-h-screen bg-black">
      <Header />
      <main className="pt-16 px-4 md:px-0">
        <HeroSection />
        <BlurredSection>
          <AnimatedElement>
            <MentorsSection />
          </AnimatedElement>
        </BlurredSection>
        <BlurredSection>
          <AnimatedElement>
            <MarketReferencesSection />
          </AnimatedElement>
        </BlurredSection>
        <BlurredSection id="programas">
          <AnimatedElement>
            <ProgramsSection />
          </AnimatedElement>
        </BlurredSection>
        <BlurredSection>
          <AnimatedElement>
            <CurriculumSection />
          </AnimatedElement>
        </BlurredSection>
      </main>
    </div>
  )
}

