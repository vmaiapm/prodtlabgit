"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { ShineBorder } from "@/components/ui/shine-border"
import { BookOpen, FileText, Headphones, FileSpreadsheet, ArrowRight } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { BookWaitlistModal } from "@/components/BookWaitlistModal"

const resources = [
  {
    title: "Papo de Produto",
    description: "Podcast com conversas autênticas sobre gestão de produtos",
    icon: Headphones,
    color: "#34495E",
    action: {
      text: "Ouça no Spotify",
      href: "https://open.spotify.com/show/6deUaOxztKmZZFE97FzhFg",
    },
  },
  {
    title: "Blog prodt lab",
    description: "Artigos e insights sobre Product Management",
    icon: FileText,
    color: "#2C3E50",
    action: {
      text: "Ler Artigos",
      href: "/blog",
    },
  },
  {
    title: "Product Manager do Futuro",
    description: "Livro essencial para PMs na era da IA",
    icon: BookOpen,
    color: "#4A4A4A",
    action: {
      text: "Lista de Espera",
      onClick: () => {},
    },
  },
  {
    title: "Templates para PMs",
    description: "Ferramentas práticas para seu dia a dia",
    icon: FileSpreadsheet,
    color: "#5D6D7E",
    action: {
      text: "Baixar Templates",
      href: "#templates",
    },
  },
]

export default function ResourcesPage() {
  const [bookWaitlistModalOpen, setBookWaitlistModalOpen] = useState(false)

  return (
    <main className="min-h-screen bg-black text-white">
      <Header />
      <section className="pt-32 pb-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-center text-white">Recursos para Product Managers</h1>
          <p className="text-xl text-gray-400 text-center mb-12 max-w-2xl mx-auto">
            Explore nossa coleção de recursos gratuitos para impulsionar sua carreira em Product Management.
          </p>

          <div className="grid md:grid-cols-2 gap-8 mb-16">
            {resources.map((resource, index) => (
              <ShineBorder key={index} className="p-6 bg-gray-900/50 rounded-lg">
                <div className="flex items-start gap-4">
                  <div className="bg-gray-800 p-3 rounded-full">
                    <resource.icon className="w-6 h-6 text-brand-500" />
                  </div>
                  <div className="flex-grow">
                    <h2 className="text-xl font-semibold mb-2 text-white">{resource.title}</h2>
                    <p className="text-gray-400 mb-4">{resource.description}</p>
                    {resource.action.onClick ? (
                      <Button
                        className="bg-brand-500 text-black hover:bg-brand-600"
                        onClick={() => {
                          if (resource.title === "Product Manager do Futuro") {
                            setBookWaitlistModalOpen(true)
                          } else {
                            resource.action.onClick()
                          }
                        }}
                      >
                        {resource.action.text}
                      </Button>
                    ) : (
                      <Link href={resource.action.href}>
                        <Button className="bg-brand-500 text-black hover:bg-brand-600">{resource.action.text}</Button>
                      </Link>
                    )}
                  </div>
                </div>
              </ShineBorder>
            ))}
          </div>

          <div id="templates" className="mt-16">
            <h2 className="text-3xl font-bold mb-8 text-center text-white">Templates para Product Managers</h2>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                { name: "Product Roadmap", image: "/placeholder.svg?height=200&width=300" },
                { name: "User Persona", image: "/placeholder.svg?height=200&width=300" },
                { name: "Feature Prioritization", image: "/placeholder.svg?height=200&width=300" },
              ].map((template, index) => (
                <ShineBorder key={index} className="p-4 bg-gray-900/50 rounded-lg">
                  <Image
                    src={template.image || "/placeholder.svg"}
                    alt={template.name}
                    width={300}
                    height={200}
                    className="rounded-lg mb-4"
                  />
                  <h3 className="text-lg font-semibold mb-2 text-white">{template.name}</h3>
                  <Button className="w-full bg-brand-500 text-black hover:bg-brand-600">
                    Baixar Template <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </ShineBorder>
              ))}
            </div>
          </div>
        </div>
      </section>

      <BookWaitlistModal
        isOpen={bookWaitlistModalOpen}
        onClose={() => setBookWaitlistModalOpen(false)}
        programTitle="Product Manager do Futuro"
      />
    </main>
  )
}

