"use client"

import { Header } from "@/components/header"
import { ShineBorder } from "@/components/ui/shine-border"
import { Button } from "@/components/ui/button"
import { Linkedin } from "lucide-react"
import Image from "next/image"
import { AnimatedElement } from "@/components/AnimatedElement"
import { useState } from "react"

const mentors = [
  {
    name: "Vinicius Maia",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%205-DSeSCOYgj1sO9In3N2vwNxpB7eB8mz.png",
    linkedinUrl: "https://www.linkedin.com/in/viniciusmaiag/",
    role: "Growth Senior Product Manager",
    bio: "Vinicius é um Product Manager experiente, especializado em crescimento e inovação. Com uma sólida trajetória em empresas líderes de tecnologia, ele combina visão estratégica e execução tática para impulsionar o sucesso dos produtos.",
    experience: [
      {
        company: "Afya",
        role: "Growth Senior Product Manager",
      },
      {
        company: "Gupy",
        role: "Senior Product Manager",
      },
      {
        company: "Tembici",
        role: "Product Manager",
      },
      {
        company: "Itaú Unibanco",
        role: "Product Manager",
      },
      {
        company: "G4 Educação",
        role: "Product Manager",
      },
    ],
  },
  {
    name: "Edson Ferreira",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%2010%20(1)-ROyDpi1kKlN5IKEp5tTiYIjG6Cp5Xj.png",
    linkedinUrl: "https://www.linkedin.com/in/edsonferreiraep/",
    role: "Group Product Manager",
    bio: "Edson é um Group Product Manager com vasta experiência em liderar equipes e produtos complexos. Sua abordagem centrada em dados e foco no cliente tem sido fundamental para o sucesso de diversos produtos digitais de alto impacto.",
    experience: [
      {
        company: "Cogna Educação",
        role: "Group Product Manager",
      },
      {
        company: "Gupy",
        role: "Senior Product Manager",
      },
      {
        company: "Picpay",
        role: "Product Manager",
      },
      {
        company: "G4 Educação",
        role: "Product Manager",
      },
    ],
  },
  {
    name: "Gabriel Breves",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%205%20(2)-IO7nYL4lYyealT5rdFMyaoPMFBoWaP.png",
    linkedinUrl: "https://www.linkedin.com/in/gabriel-breves/",
    role: "Group Product Manager",
    bio: "Gabriel é um Group Product Manager com ampla experiência em empresas líderes de tecnologia. Sua expertise abrange desde o gerenciamento de produtos em fintechs até logística e comércio eletrônico, trazendo uma visão única e inovadora.",
    experience: [
      {
        company: "Loggi",
        role: "Group Product Manager",
      },
      {
        company: "TC",
        role: "Group Product Manager",
      },
      {
        company: "PicPay",
        role: "Group Product Manager",
      },
      {
        company: "Stone",
        role: "Product Manager",
      },
      {
        company: "Empreendedor",
        role: "Fundador",
      },
    ],
  },
]

export default function MentorsPage() {
  const [showApplicationModal, setShowApplicationModal] = useState(false)
  return (
    <main className="min-h-screen bg-black">
      <Header />
      <section className="pt-32 pb-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-12 text-center text-white">Nossos Mentores</h1>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {mentors.map((mentor, index) => (
              <AnimatedElement key={index}>
                <ShineBorder className="p-8 bg-gray-900/50 rounded-lg h-full flex flex-col">
                  <div className="flex flex-col items-center text-center mb-6">
                    <Image
                      src={mentor.image || "/placeholder.svg"}
                      alt={mentor.name}
                      width={180}
                      height={180}
                      className="rounded-full mb-4"
                    />
                    <h2 className="text-2xl font-bold text-white mb-2">{mentor.name}</h2>
                    <p className="text-brand-500 mb-4">{mentor.role}</p>
                    <a
                      href={mentor.linkedinUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-gray-400 hover:text-brand-500 transition-colors"
                    >
                      <Linkedin className="w-5 h-5" />
                      <span>Ver perfil no LinkedIn</span>
                    </a>
                  </div>
                  <div className="text-left flex-grow">
                    <p className="text-gray-300 mb-6">{mentor.bio}</p>
                    <h3 className="text-lg font-semibold text-white mb-4">Experiência Profissional</h3>
                    <div className="space-y-3">
                      {mentor.experience.map((exp, idx) => (
                        <div key={idx} className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-brand-500 rounded-full" />
                          <div>
                            <span className="text-white">{exp.company}</span>
                            <span className="text-gray-400 mx-2">•</span>
                            <span className="text-gray-400">{exp.role}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </ShineBorder>
              </AnimatedElement>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-900/30">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center text-white">Compartilhe Sua Experiência</h2>
          <p className="text-xl text-gray-300 text-center mb-8 max-w-3xl mx-auto">
            Você é um profissional experiente em Product Management? Junte-se à nossa comunidade de mentores e faça a
            diferença na carreira de outros PMs.
          </p>
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <div>
              <h3 className="text-2xl font-semibold mb-4 text-white">Como você pode contribuir:</h3>
              <ul className="list-disc list-inside text-gray-300 space-y-2">
                <li>Ministrando aulas em nossos programas</li>
                <li>Oferecendo mentorias em workshops práticos</li>
                <li>Criando conteúdo exclusivo para nossa plataforma</li>
                <li>Compartilhando insights e experiências em palestras</li>
              </ul>
            </div>
            <div>
              <h3 className="text-2xl font-semibold mb-4 text-white">Por que se tornar um mentor?</h3>
              <ul className="list-disc list-inside text-gray-300 space-y-2">
                <li>Amplie sua rede de contatos na indústria</li>
                <li>Desenvolva suas habilidades de liderança e comunicação</li>
                <li>Receba compensação por suas contribuições</li>
                <li>Faça parte de uma comunidade de elite de profissionais de produto</li>
                <li>Contribua para o crescimento da próxima geração de PMs</li>
              </ul>
            </div>
          </div>
          <p className="text-center text-gray-300 mb-8">
            Valorizamos a excelência e a experiência comprovada. Por isso, realizamos um cuidadoso processo de seleção
            para garantir que nossos mentores ofereçam o mais alto padrão de qualidade em suas contribuições.
          </p>
          <div className="text-center">
            <Button
              className="bg-brand-500 text-black hover:bg-brand-600"
              onClick={() => window.open("https://forms.gle/your-google-form-url", "_blank")}
            >
              Candidate-se para ser um Colaborador
            </Button>
          </div>
        </div>
      </section>
    </main>
  )
}

