import { Header } from "@/components/header"
import { ProgramsSection } from "@/components/programs-section"
import { AnimatedElement } from "@/components/AnimatedElement"
import { BlurredSection } from "@/components/BlurredSection"

export default function ProgramasPage() {
  return (
    <main className="min-h-screen bg-black">
      <Header />
      <section className="pt-32 pb-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-8 text-center text-white">Nossos Programas</h1>
          <p className="text-xl text-gray-400 text-center mb-16 max-w-3xl mx-auto">
            Explore nossos programas de formação em Product Management, projetados para impulsionar sua carreira em
            todas as etapas.
          </p>
          <BlurredSection>
            <AnimatedElement>
              <ProgramsSection />
            </AnimatedElement>
          </BlurredSection>
        </div>
      </section>
    </main>
  )
}

