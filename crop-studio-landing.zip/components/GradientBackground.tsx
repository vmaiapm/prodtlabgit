"use client"

import { useEffect, useState } from "react"

export function GradientBackground() {
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const gradientStyle = {
    backgroundImage: `
      radial-gradient(
        circle at 50% ${Math.min(scrollY / 5, 100)}px,
        rgba(255, 215, 0, 0.15) 0%,
        rgba(255, 215, 0, 0) 50%
      ),
      linear-gradient(to bottom, #000000, #111111 50%, #000000)
    `,
    transition: "background-position 0.3s ease-out",
  }

  return <div className="fixed inset-0 w-full h-full z-[-1]" style={gradientStyle} />
}

