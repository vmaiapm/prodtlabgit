"use client"

import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import { ArrowLeft, X } from "lucide-react"
import { useState, useEffect, useRef } from "react"
import { WaitlistModal } from "./WaitlistModal"
import { SocialShareMenu } from "./SocialShareMenu"

interface BlogPost {
  title: string
  description: string
  date: string
  author: {
    name: string
    image: string
  }
  themes: string[]
  content: string
  slug: string
}

interface BlogModalProps {
  isOpen: boolean
  onClose: () => void
  post: BlogPost
  allPosts: BlogPost[]
}

export function BlogModal({ isOpen, onClose, post, allPosts }: BlogModalProps) {
  const [fontSize, setFontSize] = useState("text-base")
  const [scrollProgress, setScrollProgress] = useState(0)
  const [readingTime, setReadingTime] = useState(0)
  const contentRef = useRef<HTMLDivElement>(null)
  const [isWaitlistModalOpen, setIsWaitlistModalOpen] = useState(false)
  const [selectedWorkshop, setSelectedWorkshop] = useState("")

  useEffect(() => {
    if (contentRef.current) {
      const wordCount = contentRef.current.innerText.split(/\s+/).length
      const time = Math.ceil(wordCount / 200) // Assuming 200 words per minute reading speed
      setReadingTime(time)
    }
  }, []) // Updated dependency

  useEffect(() => {
    const handleScroll = () => {
      if (contentRef.current) {
        const scrollPosition = contentRef.current.scrollTop
        const scrollHeight = contentRef.current.scrollHeight - contentRef.current.clientHeight
        const progress = (scrollPosition / scrollHeight) * 100
        setScrollProgress(progress)
      }
    }

    const currentRef = contentRef.current
    if (currentRef) {
      currentRef.addEventListener("scroll", handleScroll)
    }

    return () => {
      if (currentRef) {
        currentRef.removeEventListener("scroll", handleScroll)
      }
    }
  }, [])

  const increaseFontSize = () => {
    if (fontSize === "text-base") setFontSize("text-lg")
    else if (fontSize === "text-lg") setFontSize("text-xl")
  }

  const decreaseFontSize = () => {
    if (fontSize === "text-xl") setFontSize("text-lg")
    else if (fontSize === "text-lg") setFontSize("text-base")
  }

  const handleWorkshopClick = (workshopTitle: string) => {
    setSelectedWorkshop(workshopTitle)
    setIsWaitlistModalOpen(true)
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-full w-full h-screen p-0 m-0 bg-white text-black overflow-hidden flex flex-col">
        <header className="bg-gray-100 p-4 flex justify-between items-center sticky top-0 z-10">
          <Button variant="ghost" onClick={onClose} className="text-gray-600 hover:text-black">
            <ArrowLeft className="h-6 w-6 mr-2" />
            Voltar
          </Button>
          <div className="flex items-center">
            <SocialShareMenu url={`https://prodtlab.com/blog/${post.slug}`} title={post.title} />
            <Button variant="ghost" onClick={onClose} className="text-gray-600 hover:text-black ml-2">
              <X className="h-6 w-6" />
            </Button>
          </div>
        </header>

        <div className="flex-grow overflow-y-auto" ref={contentRef}>
          <article className="max-w-3xl mx-auto p-8">
            <div className="mb-8">
              <div className="flex items-center gap-4 mb-4">
                <Image
                  src={post.author.image || "/placeholder.svg"}
                  alt={post.author.name}
                  width={48}
                  height={48}
                  className="rounded-full"
                />
                <div>
                  <div className="font-medium text-gray-900">{post.author.name}</div>
                  <div className="text-sm text-gray-600">{post.date}</div>
                </div>
              </div>

              <h1 className="text-3xl font-bold mb-4 text-gray-900">{post.title}</h1>
              <div className="flex flex-wrap gap-2 mb-6">
                {post.themes.map((theme, index) => (
                  <span key={index} className="text-xs bg-gray-200 text-gray-700 px-2 py-1 rounded-full">
                    {theme}
                  </span>
                ))}
              </div>
              <div className="text-sm text-gray-600 mb-4">Tempo de leitura: {readingTime} min</div>
            </div>

            <div className={`prose max-w-none ${fontSize}`} dangerouslySetInnerHTML={{ __html: post.content }} />

            {/* CTA for Paid Workshops */}
            <div className="mt-12 mb-8 bg-yellow-100 border border-yellow-300 rounded-lg p-6">
              <h2 className="text-2xl font-bold mb-4 text-gray-900">Aprimore suas habilidades em Product Management</h2>
              <p className="text-gray-700 mb-4">
                Participe de nossos workshops práticos e aprofunde seus conhecimentos em gestão de produtos.
              </p>
              <Button
                className="bg-yellow-500 text-white hover:bg-yellow-600"
                onClick={() => handleWorkshopClick("Workshop de Product Management")}
              >
                Inscreva-se em nossos Workshops
              </Button>
            </div>
          </article>
          <div
            className="fixed top-0 left-0 h-1 bg-yellow-400 transition-all duration-300"
            style={{ width: `${scrollProgress}%` }}
          />
        </div>

        <WaitlistModal
          isOpen={isWaitlistModalOpen}
          onClose={() => setIsWaitlistModalOpen(false)}
          programTitle={selectedWorkshop}
        />
      </DialogContent>
    </Dialog>
  )
}

