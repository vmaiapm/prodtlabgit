import Image from "next/image"
import { ShineBorder } from "@/components/ui/shine-border"

const testimonials = [
  {
    name: "Ana Silva",
    role: "Product Manager, TechCorp",
    image: "/placeholder.svg?height=100&width=100",
    quote:
      "O programa da prodt lab transformou minha carreira. A abordagem personalizada e os casos práticos me deram confiança para liderar projetos de alto impacto.",
  },
  {
    name: "Carlos Mendes",
    role: "Senior PM, StartupX",
    image: "/placeholder.svg?height=100&width=100",
    quote:
      "A metodologia AI-powered da prodt lab é revolucionária. Consegui identificar e preencher lacunas nas minhas habilidades que nem sabia que existiam.",
  },
  {
    name: "Juliana Ferreira",
    role: "Product Lead, InnovateNow",
    image: "/placeholder.svg?height=100&width=100",
    quote:
      "Os encontros semanais e o plano de estudos personalizado foram cruciais para minha promoção a Product Lead. Recomendo a todos os PMs ambiciosos.",
  },
]

export function TestimonialsSection() {
  return (
    <section className="py-24 bg-black">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center text-white">O Que Nossos Alunos Dizem</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <ShineBorder key={index} className="p-6 bg-gray-900/50 rounded-lg">
              <div className="flex items-center mb-4">
                <Image
                  src={testimonial.image || "/placeholder.svg"}
                  alt={testimonial.name}
                  width={50}
                  height={50}
                  className="rounded-full mr-4"
                />
                <div>
                  <h3 className="font-semibold text-white">{testimonial.name}</h3>
                  <p className="text-sm text-gray-400">{testimonial.role}</p>
                </div>
              </div>
              <p className="text-gray-300 italic">"{testimonial.quote}"</p>
            </ShineBorder>
          ))}
        </div>
      </div>
    </section>
  )
}

