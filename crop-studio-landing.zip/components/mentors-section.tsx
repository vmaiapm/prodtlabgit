"use client"

import { useState } from "react"
import { ShineBorder } from "@/components/ui/shine-border"
import { Button } from "@/components/ui/button"
import { Linkedin } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { MentorModal } from "./MentorModal"

const mentors = [
  {
    name: "Vinicius Maia",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%205-DSeSCOYgj1sO9In3N2vwNxpB7eB8mz.png",
    linkedinUrl: "https://www.linkedin.com/in/viniciusmaiag/",
    role: "Growth Senior Product Manager",
    bio: "Vinicius é um Product Manager experiente, especializado em crescimento e inovação. Com uma sólida trajetória em empresas líderes de tecnologia, ele combina visão estratégica e execução tática para impulsionar o sucesso dos produtos.",
    experience: [
      {
        company: "Afya",
        role: "Growth Senior Product Manager",
      },
      {
        company: "Gupy",
        role: "Senior Product Manager",
      },
      {
        company: "Tembici",
        role: "Product Manager",
      },
      {
        company: "Itaú Unibanco",
        role: "Product Manager",
      },
    ],
    credentials: {
      achievements: [
        "Liderou iniciativas de crescimento que resultaram em aumento de 150% na base de usuários",
        "Desenvolveu e implementou estratégia de produto que gerou ROI de 300%",
        "Mentor em programas de aceleração de startups",
        "Speaker em conferências de produto e tecnologia",
      ],
      expertise: [
        "Growth",
        "Product Strategy",
        "User Acquisition",
        "Data Analytics",
        "A/B Testing",
        "Product Led Growth",
      ],
      education: [
        "MBA em Gestão de Produtos Digitais",
        "Certificação em Growth Hacking",
        "Graduação em Engenharia de Software",
      ],
    },
  },
  {
    name: "Edson Ferreira",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%2010%20(1)-ROyDpi1kKlN5IKEp5tTiYIjG6Cp5Xj.png",
    linkedinUrl: "https://www.linkedin.com/in/edsonferreiraep/",
    role: "Group Product Manager",
    bio: "Edson é um Group Product Manager com vasta experiência em liderar equipes e produtos complexos. Sua abordagem centrada em dados e foco no cliente tem sido fundamental para o sucesso de diversos produtos digitais de alto impacto.",
    experience: [
      {
        company: "Cogna Educação",
        role: "Group Product Manager",
      },
      {
        company: "Gupy",
        role: "Senior Product Manager",
      },
      {
        company: "Picpay",
        role: "Product Manager",
      },
    ],
    credentials: {
      achievements: [
        "Gestão de portfólio de produtos com receita anual de R$50M+",
        "Liderou equipe de 15 Product Managers",
        "Implementou framework de gestão de produto em escala",
        "Palestrante em eventos de tecnologia e produto",
      ],
      expertise: [
        "Product Leadership",
        "OKRs",
        "Team Management",
        "Product Strategy",
        "Stakeholder Management",
        "B2B SaaS",
      ],
      education: ["MBA em Gestão Empresarial", "Especialização em Gestão de Produtos", "Graduação em Administração"],
    },
  },
  {
    name: "Gabriel Breves",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%205%20(2)-IO7nYL4lYyealT5rdFMyaoPMFBoWaP.png",
    linkedinUrl: "https://www.linkedin.com/in/gabriel-breves/",
    role: "Group Product Manager",
    bio: "Gabriel é um Group Product Manager com ampla experiência em empresas líderes de tecnologia. Sua expertise abrange desde o gerenciamento de produtos em fintechs até logística e comércio eletrônico, trazendo uma visão única e inovadora.",
    experience: [
      {
        company: "Loggi",
        role: "Group Product Manager",
      },
      {
        company: "TC",
        role: "Group Product Manager",
      },
      {
        company: "PicPay",
        role: "Group Product Manager",
      },
    ],
    credentials: {
      achievements: [
        "Liderou transformação digital que impactou 1M+ de usuários",
        "Desenvolveu produtos com NPS superior a 80",
        "Criou framework de discovery adotado por múltiplas empresas",
        "Mentor de mais de 50 Product Managers",
      ],
      expertise: ["Product Discovery", "User Research", "Product Strategy", "Leadership", "Agile", "Innovation"],
      education: ["Mestrado em Gestão da Inovação", "MBA em Product Management", "Graduação em Engenharia"],
    },
  },
]

export function MentorsSection() {
  const [selectedMentor, setSelectedMentor] = useState<(typeof mentors)[0] | null>(null)

  return (
    <section className="py-16 md:py-24 bg-black">
      <div className="container mx-auto px-4 md:px-6">
        <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-10 text-center text-white">
          Criadores do programa
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {mentors.map((mentor, index) => (
            <ShineBorder
              key={index}
              className="p-6 bg-black rounded-lg shadow-lg border border-gray-700 cursor-pointer transition-all duration-300 hover:bg-gray-900"
              onClick={() => setSelectedMentor(mentor)}
            >
              <div className="flex flex-col items-center text-center">
                <Image
                  src={mentor.image || "/placeholder.svg"}
                  alt={mentor.name}
                  width={180}
                  height={180}
                  className="rounded-full mb-4"
                />
                <h3 className="text-xl font-semibold text-white mb-2">{mentor.name}</h3>
                <p className="text-brand-500 mb-4">{mentor.role}</p>
                <a
                  href={mentor.linkedinUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => e.stopPropagation()}
                  className="inline-flex items-center gap-2 text-gray-400 hover:text-brand-500 transition-colors"
                >
                  <Linkedin className="w-5 h-5" />
                  <span>Ver perfil no LinkedIn</span>
                </a>
              </div>
            </ShineBorder>
          ))}
        </div>
        <div className="text-center">
          <Link href="/mentors" passHref>
            <Button className="w-full md:w-auto bg-brand-500 text-black hover:bg-brand-600">Faça parte do time</Button>
          </Link>
        </div>
      </div>

      {selectedMentor && (
        <MentorModal isOpen={!!selectedMentor} onClose={() => setSelectedMentor(null)} mentor={selectedMentor} />
      )}
    </section>
  )
}

