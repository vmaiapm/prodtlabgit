"use client"

import { useRef } from "react"
import { motion, useScroll, useTransform } from "framer-motion"

export function ParallaxBackground() {
  const ref = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  })

  const backgroundY = useTransform(scrollYProgress, [0, 1], ["0%", "50%"])

  return (
    <motion.div
      ref={ref}
      className="fixed top-0 left-0 w-full h-full z-[-1]"
      style={{
        y: backgroundY,
        backgroundImage: "radial-gradient(circle at 50% 50%, #1a1a1a 0%, #000000 100%)",
      }}
    />
  )
}

