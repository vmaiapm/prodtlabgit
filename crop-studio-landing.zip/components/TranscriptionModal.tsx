"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface TranscriptionModalProps {
  isOpen: boolean
  onClose: () => void
  episode: {
    title: string
    transcription: string
  } | null
}

export function TranscriptionModal({ isOpen, onClose, episode }: TranscriptionModalProps) {
  const [email, setEmail] = useState("")
  const [isDownloadReady, setIsDownloadReady] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Aqui você pode implementar a lógica para processar o e-mail
    // Por exemplo, enviar para um servidor, verificar se é válido, etc.
    setIsDownloadReady(true)
  }

  const handleDownload = () => {
    // Aqui você pode implementar a lógica para o download da transcrição
    // Por exemplo, gerar um arquivo de texto ou PDF com a transcrição
    const element = document.createElement("a")
    const file = new Blob([episode?.transcription || ""], { type: "text/plain" })
    element.href = URL.createObjectURL(file)
    element.download = `${episode?.title.replace(/\s+/g, "_")}_transcription.txt`
    document.body.appendChild(element)
    element.click()
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-white text-black max-w-md">
        <DialogHeader>
          <DialogTitle>{isDownloadReady ? "Download da Transcrição" : "Baixar Transcrição com IA"}</DialogTitle>
        </DialogHeader>
        {!isDownloadReady ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            <p>Insira seu e-mail para receber a transcrição gerada por IA:</p>
            <Input
              type="email"
              placeholder="seu@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <Button type="submit" className="w-full">
              Enviar
            </Button>
          </form>
        ) : (
          <div className="space-y-4">
            <p>Sua transcrição está pronta para download!</p>
            <Button onClick={handleDownload} className="w-full">
              Baixar Transcrição
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

