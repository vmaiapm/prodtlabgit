"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface MenuItem {
  id: string
  label: string
  icon: any
}

interface ResourceNavigationProps {
  items: MenuItem[]
  activeSection: string
  onSectionChange: (sectionId: string) => void
}

export function ResourceNavigation({ items, activeSection, onSectionChange }: ResourceNavigationProps) {
  const [isSticky, setIsSticky] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY
      setIsSticky(offset > 200)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <nav
      className={cn(
        "transition-all duration-300 py-4 w-full bg-black/80 backdrop-blur-lg",
        isSticky ? "fixed top-0 left-0 z-40 shadow-lg" : "",
      )}
    >
      <div className="container mx-auto px-4">
        <ul className="flex flex-wrap justify-center gap-4">
          {items.map((item) => (
            <li key={item.id}>
              <Button
                variant={activeSection === item.id ? "default" : "outline"}
                onClick={() => onSectionChange(item.id)}
                className={cn(
                  "flex items-center gap-2 transition-all duration-300 transform",
                  activeSection === item.id
                    ? "bg-yellow-400 text-black hover:bg-yellow-500 scale-105"
                    : "bg-white/10 text-white border-white/20 hover:bg-white hover:text-black",
                  "hover:scale-105",
                )}
              >
                <item.icon className="w-4 h-4" />
                {item.label}
              </Button>
            </li>
          ))}
        </ul>
      </div>
    </nav>
  )
}

