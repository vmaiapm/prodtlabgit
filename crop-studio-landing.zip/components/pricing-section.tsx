import { Button } from "@/components/ui/button"
import { ShineBorder } from "@/components/ui/shine-border"
import { Check, X } from "lucide-react"

const pricingPlans = [
  {
    name: "Curso Básico de IA para PM",
    price: "Gratuito",
    description: "Introdução às ferramentas de IA essenciais para Product Managers",
    features: [
      "Acesso vitalício ao conteúdo",
      "Visão geral das principais ferramentas de IA",
      "Casos de uso de IA em Product Management",
      "Comunidade de alunos",
      "Certificado de conclusão",
    ],
    notIncluded: ["Mentoria personalizada", "Projetos práticos avançados", "Workshops ao vivo"],
    cta: "Começar Agora",
    highlighted: false,
  },
  {
    name: "Workshop Hands-On: IA na Prática para PMs",
    price: "A partir de R$ 1.999",
    description: "Experiência prática intensiva com aplicação de IA em cenários reais de produto",
    features: [
      "Tudo do plano Gratuito",
      "Workshop prático de 8 horas",
      "Projetos reais com ferramentas de IA",
      "Mentoria individual durante o workshop",
      "30 dias de suporte pós-workshop",
      "Acesso a recursos exclusivos de IA para PM",
      "Certificado de conclusão avançado",
    ],
    notIncluded: [],
    cta: "Garantir Minha Vaga",
    highlighted: true,
  },
]

export function PricingSection() {
  return (
    <section className="py-24 bg-black">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center text-white">
          Escolha o Plano Ideal para Sua Jornada em IA e Produto
        </h2>
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {pricingPlans.map((plan, index) => (
            <ShineBorder key={index} className={`p-6 rounded-lg ${plan.highlighted ? "bg-gray-800" : "bg-gray-900"}`}>
              <h3 className="text-2xl font-bold mb-2 text-white">{plan.name}</h3>
              <p className="text-3xl font-bold mb-4 text-yellow-400">{plan.price}</p>
              <p className="text-gray-400 mb-6">{plan.description}</p>
              <ul className="mb-6 space-y-2">
                {plan.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center text-gray-300">
                    <Check className="w-5 h-5 mr-2 text-green-500" />
                    {feature}
                  </li>
                ))}
                {plan.notIncluded.map((feature, idx) => (
                  <li key={idx} className="flex items-center text-gray-500">
                    <X className="w-5 h-5 mr-2 text-red-500" />
                    {feature}
                  </li>
                ))}
              </ul>
              <Button
                className={`w-full ${plan.highlighted ? "bg-yellow-400 text-black hover:bg-yellow-500" : "bg-white text-black hover:bg-gray-200"}`}
              >
                {plan.cta}
              </Button>
            </ShineBorder>
          ))}
        </div>
      </div>
    </section>
  )
}

