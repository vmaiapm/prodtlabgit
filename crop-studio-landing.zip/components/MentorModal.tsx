"use client"

import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Linkedin, X } from "lucide-react"
import Image from "next/image"

interface MentorModalProps {
  isOpen: boolean
  onClose: () => void
  mentor: {
    name: string
    image: string
    role: string
    bio: string
    linkedinUrl: string
    experience: Array<{
      company: string
      role: string
    }>
    credentials: {
      achievements: string[]
      expertise: string[]
      education: string[]
    }
  }
}

export function MentorModal({ isOpen, onClose, mentor }: MentorModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl bg-gray-900 text-white p-0">
        <div className="relative">
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-4 top-4 text-gray-400 hover:text-white"
            onClick={onClose}
          >
            <X className="h-5 w-5" />
          </Button>

          <div className="p-6">
            <div className="flex flex-col md:flex-row gap-6 items-start">
              <div className="flex-shrink-0">
                <Image
                  src={mentor.image || "/placeholder.svg"}
                  alt={mentor.name}
                  width={200}
                  height={200}
                  className="rounded-lg"
                />
              </div>

              <div className="flex-grow">
                <h2 className="text-2xl font-bold mb-2">{mentor.name}</h2>
                <p className="text-yellow-400 mb-4">{mentor.role}</p>
                <p className="text-gray-300 mb-6">{mentor.bio}</p>

                <a
                  href={mentor.linkedinUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-blue-400 hover:text-blue-300 mb-6"
                >
                  <Linkedin className="w-5 h-5" />
                  <span>Conectar no LinkedIn</span>
                </a>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-3 text-yellow-400">Experiência</h3>
                    <div className="space-y-2">
                      {mentor.experience.map((exp, idx) => (
                        <div key={idx} className="flex items-start gap-2">
                          <div className="w-2 h-2 bg-yellow-400 rounded-full mt-2" />
                          <div>
                            <p className="font-medium text-white">{exp.company}</p>
                            <p className="text-gray-400">{exp.role}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-semibold mb-3 text-yellow-400">Conquistas</h3>
                      <ul className="list-disc list-inside text-gray-300 space-y-1">
                        {mentor.credentials.achievements.map((achievement, idx) => (
                          <li key={idx}>{achievement}</li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold mb-3 text-yellow-400">Especialidades</h3>
                      <div className="flex flex-wrap gap-2">
                        {mentor.credentials.expertise.map((skill, idx) => (
                          <span key={idx} className="bg-gray-800 px-3 py-1 rounded-full text-sm text-white">
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold mb-3 text-yellow-400">Formação</h3>
                      <ul className="list-disc list-inside text-gray-300 space-y-1">
                        {mentor.credentials.education.map((edu, idx) => (
                          <li key={idx}>{edu}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

