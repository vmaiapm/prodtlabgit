"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Share2, Linkedin, Mail, MessageCircle } from "lucide-react"

interface SocialShareMenuProps {
  url: string
  title: string
}

export function SocialShareMenu({ url, title }: SocialShareMenuProps) {
  const [isOpen, setIsOpen] = useState(false)

  const encodedUrl = encodeURIComponent(url)
  const encodedTitle = encodeURIComponent(title)

  const shareLinks = [
    {
      name: "WhatsApp",
      icon: MessageCircle,
      url: `https://wa.me/?text=${encodedTitle}%20${encodedUrl}`,
    },
    {
      name: "LinkedIn",
      icon: Linkedin,
      url: `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`,
    },
    {
      name: "Email",
      icon: Mail,
      url: `mailto:?subject=${encodedTitle}&body=${encodedUrl}`,
    },
  ]

  const handleShare = (e: React.MouseEvent<HTMLAnchorElement>, url: string) => {
    e.preventDefault()
    e.stopPropagation()
    window.open(url, "_blank", "noopener,noreferrer")
  }

  return (
    <div className="relative">
      <Button
        size="icon"
        variant="ghost"
        className="rounded-full"
        onClick={(e) => {
          e.stopPropagation()
          setIsOpen(!isOpen)
        }}
      >
        <Share2 className="h-4 w-4" />
      </Button>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" onClick={() => setIsOpen(false)}>
          <div className="absolute inset-0 bg-black opacity-50"></div>
          <div className="relative bg-white rounded-lg shadow-lg p-4" onClick={(e) => e.stopPropagation()}>
            <div className="grid grid-cols-3 gap-4">
              {shareLinks.map((link) => (
                <button
                  key={link.name}
                  className="flex flex-col items-center justify-center p-4 rounded-lg hover:bg-gray-100"
                  onClick={(e) => handleShare(e, link.url)}
                >
                  <link.icon className="w-8 h-8 mb-2 text-gray-700" />
                  <span className="text-sm text-gray-700">{link.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

