"use client"

import { Button } from "@/components/ui/button"
import { AnimatedText } from "./AnimatedText"
import { AnimatedElement } from "./AnimatedElement"
import Link from "next/link"
import { useEffect, useRef } from "react"
import Image from "next/image"
import { track } from "@vercel/analytics"

export function HeroSection() {
  const animatedPhrases = [
    "nunca param de começar",
    "sempre buscam novas alternativas",
    "estão sempre um passo à frente",
  ]

  const heroRef = useRef<HTMLElement>(null)
  const gradientRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const hero = heroRef.current
    const gradientElement = gradientRef.current
    if (!hero || !gradientElement) return

    function handleMouseMove(e: MouseEvent) {
      const gradientX = (e.clientX / window.innerWidth) * 100
      const gradientY = (e.clientY / window.innerHeight) * 100
      gradientElement.style.background = `
        radial-gradient(
          circle at ${gradientX}% ${gradientY}%,
          rgba(240, 180, 41, 0.15) 0%,
          rgba(240, 180, 41, 0.05) 30%,
          rgba(0, 0, 0, 0) 70%
        )
      `
    }

    hero.addEventListener("mousemove", handleMouseMove)

    return () => {
      hero.removeEventListener("mousemove", handleMouseMove)
    }
  }, [])

  const handleResourcesClick = () => {
    track("resources_button_clicked")
  }

  const handleProgramsClick = () => {
    track("programs_button_clicked")
  }

  return (
    <section ref={heroRef} className="relative min-h-screen overflow-hidden bg-black py-16 md:py-24">
      <div
        ref={gradientRef}
        className="absolute top-0 left-0 w-full h-full z-10 transition-all duration-300 ease-out"
      />
      <div className="relative z-20 container mx-auto px-4 md:px-6">
        <div className="flex flex-col items-center text-center">
          <AnimatedElement>
            <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold mb-6 tracking-tight leading-tight text-white">
              Para pessoas de produto que
              <br className="hidden md:inline" />
              <AnimatedText phrases={animatedPhrases} className="text-brand-500" />
            </h1>
          </AnimatedElement>
          <AnimatedElement>
            <p className="text-white text-lg mb-8 max-w-2xl">
              Capacitando gerentes de produto através de um ambiente simulado com IA, que recria a imprevisibilidade do
              dia a dia e aprimora a tomada de decisão adaptativa.
            </p>
          </AnimatedElement>
          <AnimatedElement>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/recursos" passHref>
                <Button
                  variant="outline"
                  className="w-full sm:w-auto gap-2 border-white bg-black hover:bg-white hover:text-black text-white"
                  onClick={handleResourcesClick}
                >
                  Recursos Gratuitos
                </Button>
              </Link>
              <Link href="/programas" passHref>
                <Button
                  className="w-full sm:w-auto gap-2 bg-brand-500 text-black hover:bg-brand-600"
                  onClick={handleProgramsClick}
                >
                  Nossos Programas
                </Button>
              </Link>
            </div>
          </AnimatedElement>

          <AnimatedElement>
            <div className="mt-12 text-center">
              <h2 className="text-sm md:text-base font-medium mb-4 text-gray-400">
                Aprendizados em cases reais em empresas como
              </h2>
              <div className="flex flex-wrap justify-center items-center gap-6">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo-white-SlbFQLhmalumbubJ8X5WJMI0736Vwb.webp"
                  alt="Gupy"
                  width={60}
                  height={20}
                  className="opacity-50 hover:opacity-100 transition-opacity"
                />
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo-picpay-branca-1024-hrvtIkgz2U0cEhi8PvinybNhnPCJiG.png"
                  alt="PicPay"
                  width={60}
                  height={20}
                  className="opacity-50 hover:opacity-100 transition-opacity"
                />
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo-stone-branco-2048x949-80Jx2wRxDZWk6zA9taSMThTK99npuD.webp"
                  alt="Stone"
                  width={60}
                  height={20}
                  className="opacity-50 hover:opacity-100 transition-opacity"
                />
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/4b9d2289710937.5dfd298b70828-4mgBxmwkfj0tZjoM2xsSwyHosRnsNJ.png"
                  alt="Itaú"
                  width={60}
                  height={20}
                  className="opacity-50 hover:opacity-100 transition-opacity"
                />
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/tembici.horizontal.branco-01-1024x200-uTHCxZqLKDY5HejGDR7sIFZOdA4y8Q.png"
                  alt="Tembici"
                  width={80}
                  height={20}
                  className="opacity-50 hover:opacity-100 transition-opacity"
                />
              </div>
            </div>
          </AnimatedElement>
        </div>
      </div>
    </section>
  )
}

