"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Play, AirplayIcon as Spotify } from "lucide-react"
import Image from "next/image"

interface PodcastModalProps {
  isOpen: boolean
  onClose: () => void
  episode: {
    title: string
    description: string
    image: string
    summary: string
    transcription: string
  }
}

export function PodcastModal({ isOpen, onClose, episode }: PodcastModalProps) {
  const [showTranscription, setShowTranscription] = useState(false)

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 text-white max-w-3xl">
        <DialogHeader>
          <DialogTitle>{episode.title}</DialogTitle>
          <DialogDescription>{episode.description}</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4">
          <Image
            src={episode.image || "/placeholder.svg"}
            alt={episode.title}
            width={400}
            height={400}
            className="w-full h-48 object-cover rounded-lg"
          />
          <div className="flex justify-center space-x-4">
            <Button className="bg-green-500 hover:bg-green-600">
              <Spotify className="w-4 h-4 mr-2" />
              Ouvir no Spotify
            </Button>
            <Button className="bg-yellow-400 text-black hover:bg-yellow-500">
              <Play className="w-4 h-4 mr-2" />
              Reproduzir no Site
            </Button>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-2">Resumo do Episódio</h3>
            <p className="text-gray-300">{episode.summary}</p>
          </div>
          <div>
            <Button variant="outline" onClick={() => setShowTranscription(!showTranscription)} className="w-full">
              {showTranscription ? "Ocultar Transcrição" : "Mostrar Transcrição"}
            </Button>
            {showTranscription && (
              <div className="mt-4 max-h-60 overflow-y-auto">
                <p className="text-gray-300">{episode.transcription}</p>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

