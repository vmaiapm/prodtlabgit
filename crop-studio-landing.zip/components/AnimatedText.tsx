"use client"

import type React from "react"
import { useState, useEffect } from "react"

interface AnimatedTextProps {
  phrases: string[]
  className?: string
}

export const AnimatedText: React.FC<AnimatedTextProps> = ({ phrases, className }) => {
  const [currentPhraseIndex, setCurrentPhraseIndex] = useState(0)
  const [displayedText, setDisplayedText] = useState("")
  const [isDeleting, setIsDeleting] = useState(false)

  useEffect(() => {
    let timer: NodeJS.Timeout
    const currentPhrase = phrases[currentPhraseIndex]

    if (isDeleting) {
      timer = setTimeout(() => {
        setDisplayedText(currentPhrase.substring(0, displayedText.length - 1))
        if (displayedText.length === 1) {
          setIsDeleting(false)
          setCurrentPhraseIndex((prevIndex) => (prevIndex + 1) % phrases.length)
        }
      }, 50)
    } else {
      timer = setTimeout(() => {
        setDisplayedText(currentPhrase.substring(0, displayedText.length + 1))
        if (displayedText.length === currentPhrase.length) {
          timer = setTimeout(() => setIsDeleting(true), 1000)
        }
      }, 100)
    }

    return () => clearTimeout(timer)
  }, [displayedText, isDeleting, currentPhraseIndex, phrases])

  return (
    <span className={`${className} inline-block`}>
      {displayedText}
      <span className="animate-blink">|</span>
    </span>
  )
}

