import { ShineBorder } from "@/components/ui/shine-card"
import { Button } from "@/components/ui/button"
import { ArrowRight, Users, Clock, Calendar } from "lucide-react"

const workshops = [
  {
    title: "Product Discovery Workshop",
    description:
      "Aprenda a conduzir um processo efetivo de descoberta de produto, desde a identificação de problemas até a validação de soluções.",
    duration: "4 horas",
    nextDate: "15 de Março, 2024",
    maxParticipants: 1,
    price: "R$ 2.999",
    highlights: [
      "Frameworks de descoberta",
      "Técnicas de pesquisa",
      "Validação de hipóteses",
      "Plano de ação personalizado",
    ],
  },
  {
    title: "Métricas e OKRs Workshop",
    description:
      "Desenvolva sua capacidade de definir, medir e acompanhar métricas relevantes para seu produto, alinhando-as com OKRs efetivos.",
    duration: "4 horas",
    nextDate: "22 de Março, 2024",
    maxParticipants: 1,
    price: "R$ 2.999",
    highlights: ["Definição de KPIs", "Estruturação de OKRs", "Analytics avançado", "Dashboard personalizado"],
  },
  {
    title: "Liderança de Produto Workshop",
    description:
      "Aprimore suas habilidades de liderança e aprenda a gerenciar stakeholders, times e expectativas de forma eficiente.",
    duration: "4 horas",
    nextDate: "29 de Março, 2024",
    maxParticipants: 1,
    price: "R$ 2.999",
    highlights: ["Gestão de stakeholders", "Comunicação estratégica", "Tomada de decisão", "Plano de desenvolvimento"],
  },
]

export function WorkshopsList() {
  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
      {workshops.map((workshop, index) => (
        <ShineBorder key={index} className="p-6 bg-black rounded-lg">
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-semibold mb-3 text-white">{workshop.title}</h3>
              <p className="text-gray-400 mb-4">{workshop.description}</p>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-2 text-gray-400">
                <Clock className="w-5 h-5" />
                <span>{workshop.duration}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-400">
                <Calendar className="w-5 h-5" />
                <span>{workshop.nextDate}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-400">
                <Users className="w-5 h-5" />
                <span>{workshop.maxParticipants} participante por sessão</span>
              </div>
            </div>

            <div>
              <h4 className="text-sm font-semibold text-gray-300 mb-2">O que você vai aprender:</h4>
              <ul className="space-y-2">
                {workshop.highlights.map((highlight, idx) => (
                  <li key={idx} className="text-gray-400 text-sm flex items-center gap-2">
                    <div className="w-1 h-1 bg-yellow-400 rounded-full" />
                    {highlight}
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-4">
              <div className="text-2xl font-bold text-white">{workshop.price}</div>
              <Button className="w-full bg-yellow-400 text-black hover:bg-yellow-500 gap-2">
                Agendar Workshop
                <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </ShineBorder>
      ))}
    </div>
  )
}

