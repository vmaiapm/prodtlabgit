import { ShineBorder } from "@/components/ui/shine-border"
import Image from "next/image"

const marketReferences = [
  {
    name: "Ana Silva",
    role: "CEO, TechCorp",
    image: "/placeholder.svg?height=100&width=100",
    quote:
      "Os mentores da prodt lab são verdadeiros líderes na indústria. Sua experiência e conhecimento são inestimáveis para qualquer profissional de produto.",
  },
  {
    name: "Carlos Mendes",
    role: "VP de Produto, StartupX",
    image: "/placeholder.svg?height=100&width=100",
    quote:
      "A abordagem prática e orientada por IA dos mentores da prodt lab está redefinindo o futuro da gestão de produtos. Eles estão formando os líderes de produto do amanhã.",
  },
  {
    name: "Juliana Ferreira",
    role: "Diretora de Inovação, InnovateNow",
    image: "/placeholder.svg?height=100&width=100",
    quote:
      "Os mentores da prodt lab não apenas ensinam, mas inspiram. Seu compromisso com a excelência e inovação em product management é verdadeiramente notável.",
  },
]

export function MarketReferencesSection() {
  return (
    <section className="py-8 md:py-12 bg-black">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-6 md:mb-8 text-center text-white">
          O que referências do mercado falam sobre os mentores
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
          {marketReferences.map((reference, index) => (
            <ShineBorder key={index} className="p-4 md:p-6 bg-black rounded-lg shadow-lg border border-gray-700">
              <div className="flex items-center mb-4">
                <Image
                  src={reference.image || "/placeholder.svg"}
                  alt={reference.name}
                  width={50}
                  height={50}
                  className="rounded-full mr-4"
                />
                <div>
                  <h3 className="font-semibold text-white text-base md:text-lg">{reference.name}</h3>
                  <p className="text-sm text-brand-500">{reference.role}</p>
                </div>
              </div>
              <p className="text-white italic text-sm md:text-base">"{reference.quote}"</p>
            </ShineBorder>
          ))}
        </div>
      </div>
    </section>
  )
}

