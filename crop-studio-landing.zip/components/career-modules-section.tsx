import { ShineBorder } from "@/components/ui/shine-border"
import { Button } from "@/components/ui/button"
import { ArrowRight, UserPlus, TrendingUp, Users } from "lucide-react"

const careerModules = [
  {
    title: "Migrando de Carreira para Product Manager",
    description: "Ideal para profissionais de outras áreas que desejam fazer a transição para a gestão de produtos.",
    icon: UserPlus,
    topics: [
      "Fundamentos de Product Management",
      "Metodologias Ágeis",
      "Análise de Mercado e Usuários",
      "Prototipagem e MVP",
      "Métricas e KPIs Básicos",
    ],
  },
  {
    title: "Product Manager: Trilha para se Tornar Senior",
    description: "Projetado para PMs que buscam aprimorar suas habilidades e avançar para posições seniores.",
    icon: TrendingUp,
    topics: [
      "Estratégia de Produto Avançada",
      "Liderança de Equipes Multifuncionais",
      "Análise de Dados e Tomada de Decisão",
      "Gestão de Stakeholders",
      "OKRs e Alinhamento Estratégico",
    ],
  },
  {
    title: "Senior: Trilha de Liderança de Produto",
    description:
      "Focado em desenvolver as habilidades necessárias para liderar equipes de produto e influenciar estratégias organizacionais.",
    icon: Users,
    topics: [
      "Visão e Estratégia de Produto",
      "Liderança e Desenvolvimento de Equipes",
      "Inovação e Gestão de Portfólio",
      "Métricas Avançadas e Impacto no Negócio",
      "Influência Executiva e Comunicação Estratégica",
    ],
  },
]

export function CareerModulesSection() {
  return (
    <section className="py-24 bg-black">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center text-white">Módulos de Carreira</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {careerModules.map((module, index) => (
            <ShineBorder key={index} className="p-6 bg-gray-900/50 rounded-lg">
              <div className="flex flex-col h-full">
                <div className="bg-yellow-400 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                  <module.icon className="w-6 h-6 text-black" />
                </div>
                <h3 className="text-xl font-semibold mb-3 text-white">{module.title}</h3>
                <p className="text-gray-400 mb-4 flex-grow">{module.description}</p>
                <div className="mb-4">
                  <h4 className="text-sm font-semibold text-yellow-400 mb-2">Tópicos Principais:</h4>
                  <ul className="space-y-1">
                    {module.topics.map((topic, idx) => (
                      <li key={idx} className="text-gray-300 text-sm flex items-center gap-2">
                        <div className="w-1 h-1 bg-yellow-400 rounded-full" />
                        {topic}
                      </li>
                    ))}
                  </ul>
                </div>
                <Button className="w-full bg-yellow-400 text-black hover:bg-yellow-500 mt-auto">
                  Saiba Mais
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </ShineBorder>
          ))}
        </div>
      </div>
    </section>
  )
}

