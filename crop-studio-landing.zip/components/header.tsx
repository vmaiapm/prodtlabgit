"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Instagram, Linkedin, Menu, PhoneIcon as WhatsApp } from "lucide-react"

export function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen)
  }

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-black/70 backdrop-blur-md shadow-lg" : "bg-transparent"
      }`}
    >
      <div className="container mx-auto flex items-center justify-between px-6 py-4 transition-all duration-300">
        <Link href="/" className="flex items-center">
          <span className="text-white text-xl font-bold whitespace-nowrap">
            prodt lab
            <span className="text-brand-500">.</span>
          </span>
        </Link>
        <div className="flex items-center">
          <nav className="hidden md:flex items-center gap-8 ml-auto mr-8">
            {[
              { href: "/", label: "Home" },
              { href: "/recursos", label: "Recursos" },
              { href: "/programas", label: "Programas" },
              { href: "/para-empresas", label: "Para Empresas" },
            ].map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="text-sm text-white hover:text-brand-500 transition-colors"
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="hidden md:flex gap-4 items-center">
            <a
              href="https://www.instagram.com/prodtlab"
              target="_blank"
              rel="noopener noreferrer"
              className="text-white hover:text-brand-500 transition-colors"
            >
              <Instagram size={20} />
            </a>
            <a
              href="https://www.linkedin.com/company/prodtlab"
              target="_blank"
              rel="noopener noreferrer"
              className="text-white hover:text-brand-500 transition-colors"
            >
              <Linkedin size={20} />
            </a>
            <a
              href="https://wa.me/5511999999999"
              target="_blank"
              rel="noopener noreferrer"
              className="text-white hover:text-brand-500 transition-colors"
            >
              <WhatsApp size={20} />
            </a>
          </div>
          <div className="md:hidden ml-auto">
            <button onClick={toggleMobileMenu} className="text-white hover:text-brand-500 transition-colors">
              <Menu size={24} />
            </button>
          </div>
        </div>
        {isMobileMenuOpen && (
          <div className="absolute top-full right-0 bg-black/90 backdrop-blur-md shadow-lg rounded-lg mt-2 py-2 w-48">
            {[
              { href: "/", label: "Home" },
              { href: "/recursos", label: "Recursos" },
              { href: "/programas", label: "Programas" },
              { href: "/para-empresas", label: "Para Empresas" },
            ].map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="block px-4 py-2 text-sm text-white hover:bg-gray-800 transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {item.label}
              </Link>
            ))}
            <div className="border-t border-gray-700 mt-2 pt-2 px-4 flex items-center gap-4">
              <a
                href="https://www.instagram.com/prodtlab"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white hover:text-brand-500 transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <Instagram size={20} />
              </a>
              <a
                href="https://www.linkedin.com/company/prodtlab"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white hover:text-brand-500 transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <Linkedin size={20} />
              </a>
              <a
                href="https://wa.me/5511999999999"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white hover:text-brand-500 transition-colors"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <WhatsApp size={20} />
              </a>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}

