"use client"

import type React from "react"
import { useEffect, useRef, useState } from "react"

interface BlurredSectionProps {
  children: React.ReactNode
}

export function BlurredSection({ children }: BlurredSectionProps) {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          observer.unobserve(entry.target)
        }
      },
      {
        rootMargin: "0px 0px -100px 0px",
      },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current)
      }
    }
  }, [])

  return (
    <div ref={sectionRef} className={`transition-all duration-1000 ${isVisible ? "blur-none" : "blur-md"}`}>
      {children}
    </div>
  )
}

