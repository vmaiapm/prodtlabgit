import Image from "next/image"
import Link from "next/link"

interface MentorCardProps {
  name: string
  image: string
  role: string
}

export function MentorCard({ name, image, role }: MentorCardProps) {
  return (
    <Link href="/mentors" passHref legacyBehavior>
      <a
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-3 hover:bg-gray-800/50 p-2 rounded-lg transition-colors"
      >
        <Image src={image || "/placeholder.svg"} alt={name} width={48} height={48} className="rounded-full" />
        <div>
          <span className="text-gray-300 hover:text-white transition-colors block">{name}</span>
          <span className="text-gray-400 text-sm">{role}</span>
        </div>
      </a>
    </Link>
  )
}

