"use client"

import type React from "react"
import { Brain, Rocket, Target, Users, BarChartIcon as ChartBar, Zap } from "lucide-react"

const learningSteps = [
  {
    title: "Avaliação Inicial com IA",
    description: "Utilizamos IA para analisar suas habilidades atuais e identificar áreas de melhoria.",
    icon: Brain,
  },
  {
    title: "Plano Personalizado Potencializado por IA",
    description: "Criamos um roteiro de aprendizado adaptado às suas necessidades e objetivos de carreira.",
    icon: Target,
  },
  {
    title: "Aprendizado Prático com Simulações de IA",
    description: "Aplicação de conhecimentos em projetos reais e simulações de cenários de produto.",
    icon: Rocket,
  },
  {
    title: "Mentoria Especializada Auxiliada por IA",
    description: "Sessões individuais com PMs experientes, complementadas por insights de IA.",
    icon: Users,
  },
  {
    title: "Análise de Progresso com IA Avançada",
    description: "Monitoramento contínuo do seu desenvolvimento com métricas e KPIs personalizados.",
    icon: ChartBar,
  },
  {
    title: "Aprimoramento Contínuo Guiado por IA",
    description: "Atualização constante do plano de aprendizado com base no seu progresso e nas tendências do mercado.",
    icon: Zap,
  },
]

const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
  e.preventDefault()
  const form = e.currentTarget
  const email = form.email.value
  console.log("Email submitted:", email)
  // Here you would typically send the email to your backend
  // For now, we'll just log it to the console
}

export function CurriculumSection() {
  return (
    <footer className="py-16 px-4 bg-black text-white border-t border-gray-800 mt-16">
      <div className="container mx-auto max-w-7xl">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">Recursos</h3>
            <ul className="space-y-2">
              <li>
                <a href="/blog" className="hover:text-brand-500 transition-colors">
                  Blog
                </a>
              </li>
              <li>
                <a href="/podcast" className="hover:text-brand-500 transition-colors">
                  Podcast
                </a>
              </li>
              <li>
                <a href="/materiais" className="hover:text-brand-500 transition-colors">
                  Materiais
                </a>
              </li>
              <li>
                <a href="/livro" className="hover:text-brand-500 transition-colors">
                  Livro
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-4">Redes Sociais</h3>
            <ul className="space-y-2">
              <li>
                <a
                  href="https://www.linkedin.com/company/prodtlab"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-brand-500 transition-colors"
                >
                  LinkedIn
                </a>
              </li>
              <li>
                <a
                  href="https://www.instagram.com/prodtlab"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-brand-500 transition-colors"
                >
                  Instagram
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-4">Faça parte da nossa comunidade</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="relative">
                <input
                  type="email"
                  name="email"
                  placeholder="Seu melhor e-mail"
                  className="w-full p-2 pr-24 bg-gray-800 rounded"
                  required
                />
                <button
                  type="submit"
                  className="absolute right-1 top-1 bg-brand-500 text-black py-1 px-3 rounded hover:bg-brand-600 transition-colors"
                >
                  Inscrever-se
                </button>
              </div>
              <p className="text-xs text-gray-400">Não enviamos spam. Prometemos!</p>
            </form>
          </div>
        </div>
        <div className="mt-8 text-center text-sm text-gray-400">
          © {new Date().getFullYear()} prodt lab. Todos os direitos reservados.
        </div>
      </div>
    </footer>
  )
}

