import { ShineBorder } from "@/components/ui/shine-border"
import { Button } from "@/components/ui/button"
import Link from "next/link"

const programs = [
  {
    title: "IA Essentials",
    description: "Curso introdutório sobre como as IAs estão revolucionando o trabalho dos Product Managers",
    price: "Gratuito",
    details: [
      "Visão geral das principais IAs utilizadas em Product Management",
      "Casos de uso práticos de IA na gestão de produtos",
      "Lista de prompts úteis para PMs",
      "Certificado de conclusão",
    ],
    recommendation: "Ideal para todos os PMs que querem começar a explorar o potencial da IA",
    isFeatured: true,
  },
  {
    title: "PM Essentials",
    description: "O básico que um Product Manager precisa para performar bem e entregar resultados como tríade",
    price: "R$ 1.999",
    details: [
      "12h de aula",
      "12h de prática",
      "Welcome kit materiais impressos",
      "Livros utilizados nas aulas",
      "Dinâmica com IA - contato com as principais ferramentas de IA da atualidade",
      "Plano de estudos personalizado",
    ],
    recommendation: "Recomendado para quem está migrando de carreira e ótimo para quem já é product manager em início",
  },
  {
    title: "PM Mastery",
    description: "Programa avançado para Product Managers seniores que buscam elevar suas habilidades ao próximo nível",
    price: "R$ 2.999",
    details: [
      "6 meses de mentorias mensais",
      "Workshops avançados de liderança em produto",
      "Acesso exclusivo a recursos de IA para PMs seniores",
      "Networking com líderes de produto de empresas de destaque",
      "Projeto prático de alto impacto com feedback personalizado",
      "Certificação de conclusão reconhecida no mercado",
    ],
    recommendation: "Ideal para PMs seniores que desejam se tornar líderes estratégicos em suas organizações",
  },
]

export function ProgramsSection() {
  return (
    <section id="programas" className="bg-black pt-4 sm:pt-6 md:pt-8">
      <div className="container mx-auto px-4 md:px-6 lg:px-8 pt-4 sm:pt-6 md:pt-8">
        {/* Removed h2 and p elements */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 md:gap-8 my-4 sm:my-6 md:my-8">
          {programs.map((program, index) => (
            <ShineBorder key={index} className="p-3 sm:p-4 md:p-6 bg-gray-900/50 rounded-lg flex flex-col h-full">
              <h3 className="text-lg sm:text-xl md:text-2xl font-semibold mb-2 text-white">{program.title}</h3>
              <span className="text-brand-500 font-semibold mb-4 block mt-2">{program.price}</span>
              <p className="text-gray-300 mb-4">{program.description}</p>
              {program.recommendation && <p className="text-sm text-brand-500 mb-4">{program.recommendation}</p>}
              {program.details && (
                <ul className="text-gray-300 mb-4 list-disc list-inside text-sm sm:text-base">
                  {program.details.map((detail, i) => (
                    <li key={i}>{detail}</li>
                  ))}
                </ul>
              )}
              <div className="mt-auto">
                <Link href="/programas" passHref>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full hover:bg-brand-500 hover:text-black transition-colors"
                  >
                    Entrar na Lista de Espera
                  </Button>
                </Link>
              </div>
            </ShineBorder>
          ))}
        </div>
      </div>
    </section>
  )
}

