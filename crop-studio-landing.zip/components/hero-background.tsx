"use client"

import { useEffect, useRef } from "react"

export function HeroBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Configurar o canvas para tela cheia
    const resizeCanvas = () => {
      const { innerWidth: width, innerHeight: height } = window
      const dpr = window.devicePixelRatio || 1
      canvas.width = width * dpr
      canvas.height = height * dpr
      canvas.style.width = `${width}px`
      canvas.style.height = `${height}px`
      ctx.scale(dpr, dpr)
      return { width, height }
    }

    let { width, height } = resizeCanvas()
    window.addEventListener("resize", () => {
      const dims = resizeCanvas()
      width = dims.width
      height = dims.height
    })

    // Criar gradientes animados
    const gradients = [
      { x: width * 0.2, y: height * 0.3, radius: 300, color: "rgba(255, 215, 0, 0.03)" },
      { x: width * 0.8, y: height * 0.7, radius: 250, color: "rgba(255, 215, 0, 0.02)" },
      { x: width * 0.5, y: height * 0.5, radius: 400, color: "rgba(255, 215, 0, 0.015)" },
    ]

    let frame = 0
    const animate = () => {
      frame++
      ctx.fillStyle = "rgba(0, 0, 0, 0.95)"
      ctx.fillRect(0, 0, width, height)

      gradients.forEach((gradient, i) => {
        const time = frame * 0.002 + (i * Math.PI) / 3
        const x = gradient.x + Math.cos(time) * 50
        const y = gradient.y + Math.sin(time) * 50

        const radialGradient = ctx.createRadialGradient(x, y, 0, x, y, gradient.radius)
        radialGradient.addColorStop(0, gradient.color)
        radialGradient.addColorStop(1, "transparent")

        ctx.fillStyle = radialGradient
        ctx.beginPath()
        ctx.arc(x, y, gradient.radius, 0, Math.PI * 2)
        ctx.fill()
      })

      requestAnimationFrame(animate)
    }

    animate()

    return () => {
      // Cleanup
      cancelAnimationFrame(frame)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      className="fixed top-0 left-0 w-full h-full -z-10"
      style={{ background: "linear-gradient(to bottom, #000000, #111111 50%, #000000)" }}
    />
  )
}

